# -*- coding: utf-8 -*-
"""
auto fish by barabaka
Fishing helper for GTA V (RAGE MP) with a dark animated GUI.

1 : horizontal bar, hook must be hit in the centre of the green zone -> one click.
2 : vertical bar (green top / red bottom). A clicker starts RIGHT AFTER 1 and taps LMB without pauses
    at 15 clicks/sec until the menu 2 is over, then it switches itself off and the bot waits for 1 again.
The bot scans the whole selected game window, locks onto the bar and tracks it.
Then everything repeats.
"""
import sys
import os
import json
import time
import math
import html
import random
import threading
import ctypes
from ctypes import wintypes

if sys.platform != "win32":
    print("This program works on Windows only.")
    sys.exit(1)

import numpy as np
import mss
import mss.tools
from PySide6.QtCore import (Qt, QThread, Signal, QTimer, QPropertyAnimation, QEasingCurve,
                            QRectF, QPointF, Property, QVariantAnimation, QRect)
from PySide6.QtGui import (QColor, QPainter, QPainterPath, QLinearGradient, QRadialGradient,
                           QFont, QPen, QBrush, QPixmap)
from PySide6.QtWidgets import (QApplication, QWidget, QFrame, QLabel, QPushButton, QComboBox,
                               QVBoxLayout, QHBoxLayout, QPlainTextEdit,
                               QGraphicsOpacityEffect)

# ----------------------------------------------------------------------------
#  constants
# ----------------------------------------------------------------------------
APP_NAME = "auto fish by barabaka"
CREATOR = "nonininino1212w321"

ACCENT = "#f2f2f2"      # main highlight: soft white
DANGER = "#c8c8c8"
STOP_COL = "#595959"    # STOP button
WARN = "#cdcdcd"
INFO = "#b3b3b3"
ORANGE = "#949494"
TEXT = "#eaeaea"
MUTED = "#828282"
BORDER = "#222222"

# detection / clicking tuning
STEP = 2               # down-sampling of the frame for colour masks
LEAD = 0.020           # seconds: input latency (capture + detection time is added automatically)
TOL_FRAC = 0.09        # hit tolerance as a fraction of the green core width
CLICK_HOLD = 0.006     # mouse button hold time
CLICK_GAP = 0.012      # pause between clicks while spamming (2)
GONE_AFTER = 0.35      # seconds without the menu 2 before the cycle is considered finished
CENTER_FRAC = 0.03     # 1: allowed offset from the exact centre of the green zone (fraction of zone width)
INNER_FRAC = 0.35      # 1: the hook must be inside this central part of the green zone (half-width fraction)
CLICK_HOLD_1 = 0.020   # 1: single click hold time
WAIT2_POLL = 0.05      # 2: while waiting for the menu the screen is scanned only this often
CLICK2_MAX = 45.0      # 2: safety limit - stop spamming after this many seconds
WAIT2_TIMEOUT = 45.0   # seconds to wait for 2 after a hit before going back to 1
CLICKER_CPS = 15.0     # 2: DEFAULT SIMPLE AUTOCLICKER - 15 CLICKS PER SECOND
SPAM_POLL = 0.03       # 2: how often (s) the screen is looked at while the clicker works
SPAM_GONE_AFTER = 0.3  # 2: the menu 2 must be gone for this long before the clicker is switched off

CFG_PATH = os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "abf_settings.json")
CFG = {"hotkey": 0x75, "animations": True, "console": True, "lang": "ru",
       "lead_ms": 20, "click_method": "sendinput",
       "click2_method": "sendinput", "click2_center": True,
       "tas": False,
       "stage2": "clicker",
       "clicker_method": "sendinput",
       "clicker_cps": 15.0}


def load_cfg():
    try:
        with open(CFG_PATH, "r", encoding="utf-8") as f:
            CFG.update(json.load(f))
    except Exception:
        pass


def save_cfg():
    try:
        with open(CFG_PATH, "w", encoding="utf-8") as f:
            json.dump(CFG, f, indent=2)
    except Exception:
        pass


def anim_on():
    return bool(CFG.get("animations", True))


# ----------------------------------------------------------------------------
#  localisation (EN / RU)
# ----------------------------------------------------------------------------
TR = {
    "en": {
        "proc_title": "1 · GAME PROCESS",
        "note_title": "2 · BEFORE YOU START",
        "note_text": "Before starting the script, take the fishing rod and choose \u201cFish\u201d",
        "ok": "OK",
        "start": "START", "stop": "STOP",
        "hk": "%s · start / stop",
        "hits": "HITS", "cycles": "CYCLES", "uptime": "UPTIME",
        "console": "CONSOLE",
        "st_idle": "IDLE",
        "st_wait1": "WAITING 1",
        "st_wait2": "WAITING 2",
        "st_click": "CLICKING",
        "st_paused": "PAUSED · GAME NOT FOCUSED",
        "settings": "SETTINGS",
        "set_key": "Start / Stop key",
        "set_key_d": "works even when the game is focused",
        "press_key": "press a key\u2026",
        "set_anim": "Animations",
        "set_anim_d": "turn off on low-end PCs",
        "set_console": "Action console",
        "set_console_d": "show script log window",
        "creator": "creator ds: %s",
        "log_ready": "auto fish by barabaka ready",
        "log_hint": "select the game process, take the rod and choose \u00abfishing\u00bb, then press START / %s",
        "log_selproc": "select a game process first (press \u27f3 to refresh)",
        "log_started": "script started · %s",
        "log_stopped": "script stopped",
        "w_wait1": "waiting 1...",
        "w_seen1": "1 detected",
        "w_closed": "game window closed",
        "w_capfail": "capture failed: %r",
        "w_nofocus": "game window is not focused - paused",
        "w_hit": "1 hitted",
        "w_wait": "wait",
        "w_click": "2 detected - clicking",
        "w_retry": "1 again - retry",
        "w_timeout": "2 timeout - waiting 1",
        "w_gone": "2 gone - waiting 1...",
        "w_fatal": "fatal error: %r",
        "w_profile": "colour profile: %s",
        "w_dbg": "2 not seen for a long time - screenshot saved: %s",
        "w_hitinfo": "offset from centre: %+d px (predicted %+d px)",
        "w_method": "click method: %s",
        "tas_play": "TAS: replaying the recording (%d actions, %.1f s)",
        "tas_done": "TAS: finished - waiting 1...",
        "log_noadmin": "not running as administrator - the game may ignore clicks. Restart the script as admin",
        "w_clk_on": "autoclicker ON \u00b7 15 clicks/s — clicking stage 2",
        "w_clk_off": "autoclicker OFF \u00b7 clicks made: %d",
        "w_seen2": "2 detected — autoclicker active",
    },
    "ru": {
        "proc_title": "1 · ПРОЦЕСС ИГРЫ",
        "note_title": "2 · ПЕРЕД ЗАПУСКОМ",
        "note_text": "Перед запуском скрипта возьмите удочку и выберите «Ловить рыбу»",
        "ok": "OK",
        "start": "СТАРТ", "stop": "СТОП",
        "hk": "%s · старт / стоп",
        "hits": "ХИТЫ", "cycles": "ЦИКЛЫ", "uptime": "ВРЕМЯ",
        "console": "КОНСОЛЬ",
        "st_idle": "ПРОСТОЙ",
        "st_wait1": "ЖДУ 1",
        "st_wait2": "ЖДУ 2",
        "st_click": "КЛИКАЮ (15 кл/с)",
        "st_paused": "ПАУЗА · НЕТ ФОКУСА",
        "settings": "НАСТРОЙКИ",
        "set_key": "Клавиша старт / стоп",
        "set_key_d": "работает, даже когда игра в фокусе",
        "press_key": "нажмите клавишу\u2026",
        "set_anim": "Анимации",
        "set_anim_d": "отключите на слабых ПК",
        "set_console": "Консоль действий",
        "set_console_d": "окно логов скрипта",
        "creator": "создатель ds: %s",
        "log_ready": "auto fish by barabaka готов",
        "log_hint": "выберите процесс игры, возьмите удочку и выберите «Ловить рыбу», затем нажмите СТАРТ / %s",
        "log_selproc": "сначала выберите процесс игры (\u27f3 — обновить список)",
        "log_started": "скрипт запущен · %s",
        "log_stopped": "скрипт остановлен",
        "w_wait1": "жду 1...",
        "w_seen1": "1 найдено",
        "w_closed": "окно игры закрыто",
        "w_capfail": "сбой захвата: %r",
        "w_nofocus": "окно игры не в фокусе — пауза",
        "w_hit": "1 попал",
        "w_wait": "жду",
        "w_click": "2 найдено — кликаю",
        "w_retry": "снова 1 — повтор",
        "w_timeout": "таймаут 2 — жду 1",
        "w_gone": "2 пропало — жду 1...",
        "w_fatal": "критическая ошибка: %r",
        "w_profile": "цветовой профиль: %s",
        "w_dbg": "2 долго не видно — скриншот сохранён: %s",
        "w_hitinfo": "отклонение от центра: %+d px (прогноз %+d px)",
        "w_method": "метод клика: %s",
        "tas_play": "TAS: повторяю запись (%d действий, %.1f с)",
        "tas_done": "TAS: готово — жду 1...",
        "log_noadmin": "запущено не от администратора - игра может игнорировать клики. Перезапустите скрипт от админа",
        "w_clk_on": "автокликер ВКЛ \u00b7 15 кл/с — кликаю до завершения 2",
        "w_clk_off": "автокликер ВЫКЛ \u00b7 кликов сделано: %d",
        "w_seen2": "2 найдено — автокликер работает",
    },
}


def t(key, *args):
    lang = CFG.get("lang", "ru")
    txt = TR.get(lang, TR["en"]).get(key) or TR["en"].get(key, key)
    return (txt % args) if args else txt


# ----------------------------------------------------------------------------
#  WinAPI helpers
# ----------------------------------------------------------------------------
user32 = ctypes.windll.user32
kernel32 = ctypes.windll.kernel32
winmm = ctypes.windll.winmm
try:
    dwmapi = ctypes.windll.dwmapi
except Exception:
    dwmapi = None

HWND = wintypes.HWND
user32.IsWindowVisible.argtypes = [HWND]
user32.IsWindow.argtypes = [HWND]
user32.IsIconic.argtypes = [HWND]
user32.GetWindowTextLengthW.argtypes = [HWND]
user32.GetWindowTextW.argtypes = [HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [HWND, ctypes.POINTER(wintypes.DWORD)]
user32.GetClientRect.argtypes = [HWND, ctypes.POINTER(wintypes.RECT)]
user32.ClientToScreen.argtypes = [HWND, ctypes.POINTER(wintypes.POINT)]
user32.GetForegroundWindow.restype = HWND
user32.SetForegroundWindow.argtypes = [HWND]
user32.ShowWindow.argtypes = [HWND, ctypes.c_int]
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
user32.ScreenToClient.argtypes = [HWND, ctypes.POINTER(wintypes.POINT)]
user32.PostMessageW.argtypes = [HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)
user32.EnumWindows.argtypes = [WNDENUMPROC, wintypes.LPARAM]


def process_name(pid):
    h = kernel32.OpenProcess(0x1000, False, pid)
    if not h:
        return "?"
    try:
        buf = ctypes.create_unicode_buffer(520)
        size = wintypes.DWORD(520)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return os.path.basename(buf.value)
    finally:
        kernel32.CloseHandle(h)
    return "?"


def is_cloaked(hwnd):
    if dwmapi is None:
        return False
    try:
        val = wintypes.DWORD(0)
        dwmapi.DwmGetWindowAttribute(HWND(hwnd), 14, ctypes.byref(val), 4)
        return val.value != 0
    except Exception:
        return False


SKIP_TITLES = {"Program Manager", "Windows Input Experience", "Microsoft Text Input Application"}


def list_windows():
    result = []
    me = os.getpid()

    def cb(hwnd, _):
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            n = user32.GetWindowTextLengthW(hwnd)
            if n <= 0:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(hwnd, buf, n + 1)
            title = buf.value.strip()
            if not title or title in SKIP_TITLES or is_cloaked(hwnd):
                return True
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value == me:
                return True
            result.append({"hwnd": int(hwnd), "pid": pid.value,
                           "name": process_name(pid.value), "title": title})
        except Exception:
            pass
        return True

    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return result


def client_rect(hwnd):
    if not user32.IsWindow(hwnd):
        return None
    r = wintypes.RECT()
    if not user32.GetClientRect(hwnd, ctypes.byref(r)):
        return None
    pt = wintypes.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(pt))
    if r.right <= 0 or r.bottom <= 0:
        return None
    return pt.x, pt.y, r.right, r.bottom


def focus_window(hwnd):
    try:
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)
        user32.keybd_event(0x12, 0, 0, 0)
        user32.keybd_event(0x12, 0, 2, 0)
        user32.SetForegroundWindow(hwnd)
    except Exception:
        pass


ULONG_PTR = ctypes.c_size_t


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ULONG_PTR)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


def _mouse_event(flags):
    inp = INPUT(type=0)
    inp.mi = MOUSEINPUT(0, 0, 0, flags, 0, 0)
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def mouse_click(hold=CLICK_HOLD):
    """Standard direct mouse click via SendInput."""
    _mouse_event(0x0002)   # left down
    time.sleep(hold)
    _mouse_event(0x0004)   # left up


def release_lmb():
    """Safety release of left mouse button."""
    try:
        _mouse_event(0x0004)
        user32.mouse_event(0x0004, 0, 0, 0, 0)
    except Exception:
        pass


KEY_NAMES = {0x04: "Mouse3", 0x05: "Mouse4", 0x06: "Mouse5", 0x08: "Backspace", 0x09: "Tab",
             0x0D: "Enter", 0x10: "Shift", 0x11: "Ctrl", 0x12: "Alt", 0x13: "Pause",
             0x14: "CapsLock", 0x20: "Space", 0x21: "PageUp", 0x22: "PageDown", 0x23: "End",
             0x24: "Home", 0x25: "Left", 0x26: "Up", 0x27: "Right", 0x28: "Down",
             0x2D: "Insert", 0x2E: "Delete"}


def vk_name(vk):
    if vk in KEY_NAMES:
        return KEY_NAMES[vk]
    if 0x70 <= vk <= 0x87:
        return "F%d" % (vk - 0x6F)
    if 0x30 <= vk <= 0x39 or 0x41 <= vk <= 0x5A:
        return chr(vk)
    if 0x60 <= vk <= 0x69:
        return "Num%d" % (vk - 0x60)
    try:
        sc = user32.MapVirtualKeyW(vk, 0)
        buf = ctypes.create_unicode_buffer(64)
        if user32.GetKeyNameTextW(sc << 16, buf, 64) > 0:
            return buf.value
    except Exception:
        pass
    return "VK_%02X" % vk


# ----------------------------------------------------------------------------
#  detection
# ----------------------------------------------------------------------------
def _largest_cluster(idx, gap=3):
    parts = np.split(idx, np.nonzero(np.diff(idx) > gap)[0] + 1)
    return max(parts, key=len)


def _find_h(out, st, green, red, greenness, r, g, b):
    sh, sw = green.shape
    cand = np.nonzero(green.sum(axis=1) >= 10)[0]
    if not cand.size:
        return False
    best = None
    for grp in np.split(cand, np.nonzero(np.diff(cand) > 1)[0] + 1):
        gh = int(grp.size)
        if gh < 3 or gh > 30:
            continue
        ya, yb = int(grp[0]), int(grp[-1]) + 1
        colsum = green[ya:yb].sum(axis=0)
        cols = np.nonzero(colsum >= max(2, gh * 0.5))[0]
        if cols.size < 12:
            continue
        cl = _largest_cluster(cols, gap=6)
        x0, x1 = int(cl[0]), int(cl[-1])
        gw = x1 - x0 + 1
        if gw < gh * 2.5:
            continue
        n = int(colsum[x0:x1 + 1].sum())
        if n < 0.3 * gw * gh:
            continue
        half = max(int(gh * 7.5), gw // 2 + 4)
        lx = max(0, x0 - half)
        rx = min(sw, x1 + 1 + half)
        ry0 = max(0, ya - 1)
        ry1 = min(sh, yb + 1)
        rd = red[ry0:ry1, lx:rx]
        lc = int(np.count_nonzero(rd[:, :x0 - lx]))
        rc = int(np.count_nonzero(rd[:, x1 + 1 - lx:]))
        if lc < gh or rc < gh:
            continue
        if best is None or n > best[0]:
            best = (n, ya, yb, x0, x1, lx, rx, ry0, ry1)
    if best is None:
        return False
    _, ya, yb, x0, x1, lx, rx, ry0, ry1 = best
    out["stage"] = 1
    out["green"] = (x0 * st, ya * st, (x1 + 1) * st, yb * st)

    rr, gg, bb = r[ry0:ry1, lx:rx], g[ry0:ry1, lx:rx], b[ry0:ry1, lx:rx]
    mn = np.minimum(np.minimum(rr, gg), bb)
    mx = np.maximum(np.maximum(rr, gg), bb)
    pale = (mn > 100) & ((mx - mn) < 150) & ((gg - np.maximum(rr, bb)) < 40)
    cnt = pale.sum(axis=0)
    hooks = []
    pc = np.nonzero(cnt >= 1)[0]
    if pc.size:
        for grp in np.split(pc, np.nonzero(np.diff(pc) > 2)[0] + 1):
            n = int(cnt[grp].sum())
            wpx = (int(grp[-1]) - int(grp[0]) + 1) * st
            if n >= 3 and wpx <= 60:
                hooks.append(((lx + (float(grp[0]) + float(grp[-1])) / 2.0 + 0.5) * st, wpx, n))
    hooks.sort(key=lambda hk: -hk[2])
    out["hooks"] = hooks
    if hooks:
        out["hook"], out["hook_w"] = hooks[0][0], hooks[0][1]

    rows = slice(ya + 1, yb - 1) if yb - ya >= 5 else slice(ya, yb)
    d = np.median((g - r)[rows, lx:rx], axis=0).astype(np.float32)
    bad = np.zeros(d.size, dtype=bool)
    for hx, hw, _n in hooks:
        i0 = int((hx - hw / 2.0) / st) - lx - 2
        i1 = int((hx + hw / 2.0) / st) - lx + 2
        bad[max(0, i0):max(0, i1 + 1)] = True
    if bad.any() and int((~bad).sum()) > 4:
        xi = np.arange(d.size)
        d[bad] = np.interp(xi[bad], xi[~bad], d[~bad])
    dsm = np.convolve(d, np.ones(3, dtype=np.float32) / 3.0, mode="same")
    thr = 10.0
    pk_i = int(np.argmax(dsm))
    li = pk_i
    while li > 0 and dsm[li - 1] > thr:
        li -= 1
    ri = pk_i
    while ri < dsm.size - 1 and dsm[ri + 1] > thr:
        ri += 1
    zl, zr = lx + li, lx + ri + 1
    zw = max(1.0, (zr - zl) * st)
    out["zone"] = (zl * st, zr * st)
    out["center"] = (zl + zr) / 2.0 * st
    out["tol"] = max(3.0, zw * CENTER_FRAC)
    out["inner"] = zw * INNER_FRAC

    ok = None
    if hooks:
        off = int(out["hook_w"] / 2.0 / st) + 3
        ci = int(out["hook"] / st) - lx
        a_, b_ = ci - off, ci + off
        ok = bool(0 <= a_ < dsm.size and 0 <= b_ < dsm.size and dsm[a_] > thr and dsm[b_] > thr)
    out["colour_ok"] = ok
    return True


def _find_v(out, st, green, red):
    sh, sw = green.shape
    cand = np.nonzero(green.sum(axis=0) >= 6)[0]
    if not cand.size:
        return False
    best = None
    for grp in np.split(cand, np.nonzero(np.diff(cand) > 1)[0] + 1):
        gw = int(grp.size)
        if gw < 2 or gw > 40:
            continue
        xa, xb = int(grp[0]), int(grp[-1]) + 1
        rowsum = green[:, xa:xb].sum(axis=1)
        rows = np.nonzero(rowsum >= max(2, gw * 0.5))[0]
        if rows.size < 6:
            continue
        cl = _largest_cluster(rows)
        y0, y1 = int(cl[0]), int(cl[-1])
        gh = y1 - y0 + 1
        if gh < gw * 1.1:
            continue
        n = int(rowsum[y0:y1 + 1].sum())
        if n < 0.35 * gw * gh:
            continue
        rx0 = max(0, xa - gw // 2)
        rx1 = min(sw, xb + gw // 2)
        ry0 = y1 + 1
        ry1 = min(sh, y1 + 1 + gh * 3)
        sub = red[ry0:ry1, rx0:rx1]
        if int(np.count_nonzero(sub)) < 0.35 * gw * gh:
            continue
        if best is None or n > best[0]:
            ys2, xs2 = np.nonzero(sub)
            best = (n, xa, xb, y0, y1,
                    ((rx0 + int(xs2.min())) * st, (ry0 + int(ys2.min())) * st,
                     (rx0 + int(xs2.max()) + 1) * st, (ry0 + int(ys2.max()) + 1) * st))
    if best is None:
        return False
    _, xa, xb, y0, y1, rbox = best
    out["stage"] = 2
    out["green"] = (xa * st, y0 * st, xb * st, (y1 + 1) * st)
    out["red"] = rbox
    return True


PROFILES = (
    {"name": "normal", "g": 78, "gn": 28, "r1": 100, "rd": 50, "r2": 110, "lo": 85},
    {"name": "dim",    "g": 55, "gn": 16, "r1": 80,  "rd": 32, "r2": 90,  "lo": 75},
    {"name": "bright", "g": 120, "gn": 24, "r1": 135, "rd": 42, "r2": 140, "lo": 110},
    {"name": "faint",  "g": 40,  "gn": 10, "r1": 65,  "rd": 22, "r2": 70,  "lo": 65},
)


def detect(frame, st=STEP, want=None, profile=0):
    h, w = frame.shape[:2]
    out = {"stage": 0, "green": None, "red": None, "hook": None, "center": None,
           "tol": 0.0, "crop_w": w, "crop_h": h,
           "hooks": [], "hook_w": 0, "zone": None, "inner": 0.0, "colour_ok": None}
    s = frame[::st, ::st]
    b = s[:, :, 0].astype(np.int16)
    g = s[:, :, 1].astype(np.int16)
    r = s[:, :, 2].astype(np.int16)

    pf = PROFILES[profile % len(PROFILES)]
    greenness = g - np.maximum(r, b)
    green = (g > pf["g"]) & (greenness > pf["gn"])
    red = (((r > pf["r1"]) & (r > g + pf["rd"]) & (r > b + pf["rd"]))
           | ((r > pf["r2"]) & (g < pf["lo"]) & (b < pf["lo"])))

    if want in (None, 1) and _find_h(out, st, green, red, greenness, r, g, b):
        return out
    if want in (None, 2):
        _find_v(out, st, green, red)
    return out


def _shift_info(info, ox, oy):
    for k in ("center", "hook"):
        if info[k] is not None:
            info[k] += ox
    info["hooks"] = [(hx + ox, hw, n) for hx, hw, n in info["hooks"]]
    if info["zone"] is not None:
        info["zone"] = (info["zone"][0] + ox, info["zone"][1] + ox)
    for k in ("green", "red"):
        bx = info[k]
        if bx is not None:
            info[k] = (bx[0] + ox, bx[1] + oy, bx[2] + ox, bx[3] + oy)


def _make_roi(info, W, H):
    g = info["green"]
    if g is None:
        return None
    if info["stage"] == 1:
        gw, gh = g[2] - g[0], g[3] - g[1]
        mx = max(int(gw * 0.9), int(gh * 8)) + 24
        my = int(gh * 2) + 24
        x0, y0, x1, y1 = g[0] - mx, g[1] - my, g[2] + mx, g[3] + my
    else:
        boxes = [bx for bx in (g, info["red"]) if bx]
        x0 = min(bx[0] for bx in boxes)
        y0 = min(bx[1] for bx in boxes)
        x1 = max(bx[2] for bx in boxes)
        y1 = max(bx[3] for bx in boxes)
        mx = int((x1 - x0) * 0.5) + 60
        my = int((y1 - y0) * 0.3) + 60
        x0, y0, x1, y1 = x0 - mx, y0 - my, x1 + mx, y1 + my
    x0, y0, x1, y1 = max(0, int(x0)), max(0, int(y0)), min(W, int(x1)), min(H, int(y1))
    if x1 - x0 < 32 or y1 - y0 < 32:
        return None
    return x0, y0, x1 - x0, y1 - y0


def _blank(info):
    info.update({"stage": 0, "green": None, "red": None, "hook": None, "center": None, "tol": 0.0,
                 "hooks": [], "zone": None, "inner": 0.0, "colour_ok": None})
    return info


def scan_all(frame, step, want, profile, cand_prof, acc_prof):
    found_p = None
    info = None
    for p_ in [profile] + [q for q in range(len(PROFILES)) if q != profile]:
        info = detect(frame, step, want, p_)
        if info["stage"]:
            found_p = p_
            break
    if found_p is None:
        return info, profile, None, acc_prof, None
    if found_p != 0 and info["stage"] == 1 and cand_prof != found_p:
        return _blank(info), found_p, found_p, acc_prof, None
    new = PROFILES[found_p]["name"] if found_p != acc_prof else None
    return info, found_p, (found_p if found_p != 0 else None), found_p, new


class ClickPlanner:
    def __init__(self):
        self.reset()

    def reset(self):
        self.hist = []
        self.prev_x = self.prev_t = self.prev_pred = None
        self.stuck_start_time = None

    def update(self, now, pos, c, tol, inner, colour_ok, lead):
        if self.stuck_start_time is None:
            self.stuck_start_time = now

        # Улучшенная защита от зависания: если висим на 1 этапе > 0.9 сек, форсируем клик
        time_in_stage = now - self.stuck_start_time
        dist_to_center = abs(pos - c)
        if time_in_stage > 0.9 and dist_to_center <= (inner * 1.5):
            return True, pos

        self.hist.append((now, pos))
        self.hist[:] = [h for h in self.hist[-6:] if now - h[0] <= 0.15]
        v = 0.0
        if len(self.hist) >= 2:
            ts = np.array([h[0] for h in self.hist])
            xs = np.array([h[1] for h in self.hist])
            tm = ts - ts.mean()
            den = float((tm * tm).sum())
            if den > 1e-9:
                v = float((tm * (xs - xs.mean())).sum() / den)
        
        pred = pos + v * lead
        crossed = self.prev_pred is not None and (self.prev_pred - c) * (pred - c) <= 0
        move = abs(pos - self.prev_x) if self.prev_x is not None else 0.0
        in_green = colour_ok is not False and abs(pos - c) <= inner and abs(pred - c) <= inner
        at_centre = abs(pred - c) <= min(inner, max(tol, 0.6 * move))
        fire = bool(in_green and (at_centre or crossed))
        self.prev_x, self.prev_t, self.prev_pred = pos, now, pred
        return fire, pred


# ----------------------------------------------------------------------------
#  worker thread / simple 15 CPS autoclicker
# ----------------------------------------------------------------------------
class AutoClicker15(threading.Thread):
    """Simple, dedicated auto-clicker running at 15 clicks/sec."""

    def __init__(self, hwnd):
        super().__init__(daemon=True)
        self.hwnd = hwnd
        self._on = threading.Event()
        self._alive = True
        self.count = 0

    @property
    def active(self):
        return self._on.is_set()

    def start_clicking(self):
        self.count = 0
        self._on.set()

    def stop_clicking(self):
        self._on.clear()

    def shutdown(self):
        self._alive = False
        self._on.set()

    def run(self):
        interval = 1.0 / 15.0
        while self._alive:
            if not self._on.is_set():
                release_lmb()
                self._on.wait(0.05)
                continue
            
            if (user32.GetForegroundWindow() or 0) == self.hwnd:
                try:
                    mouse_click(CLICK_HOLD)
                    self.count += 1
                except Exception:
                    pass
            
            time.sleep(interval)
        release_lmb()


class Worker(QThread):
    log = Signal(str, str)
    state = Signal(str)
    hit = Signal()
    cycle = Signal()

    def __init__(self, hwnd):
        super().__init__()
        self.hwnd = hwnd
        self._run = True
        self._shown = None
        self.clicker = None

    def stop(self):
        self._run = False

    def _safe_click(self, hold=CLICK_HOLD_1):
        if (user32.GetForegroundWindow() or 0) != self.hwnd:
            return False
        mouse_click(hold)
        return True

    def _save_debug(self, shot):
        try:
            d = os.path.join(os.path.dirname(CFG_PATH), "abf_debug")
            os.makedirs(d, exist_ok=True)
            if len(os.listdir(d)) >= 8:
                return
            path = os.path.join(d, "wait2_%s.png" % time.strftime("%H%M%S"))
            mss.tools.to_png(shot.rgb, shot.size, output=path)
            self.log.emit(t("w_dbg", path), "warn")
        except Exception:
            pass

    @staticmethod
    def _pick_hook(info, prev_x):
        hooks = info.get("hooks") or []
        if not hooks:
            return None
        if prev_x is not None:
            g = info["green"]
            limit = max(60.0, 0.6 * (g[2] - g[0])) if g else 120.0
            best = min(hooks, key=lambda hk: abs(hk[0] - prev_x))
            if abs(best[0] - prev_x) <= limit:
                return best[0]
        return hooks[0][0]

    def _set_state(self, s):
        if s != self._shown:
            self._shown = s
            self.state.emit(s)

    def run(self):
        winmm.timeBeginPeriod(1)
        release_lmb()
        self.clicker = AutoClicker15(self.hwnd)
        self.clicker.start()
        try:
            self._loop()
        except Exception as e:
            self.log.emit(t("w_fatal", e), "err")
        finally:
            self.clicker.shutdown()
            self.clicker.join(1.0)
            release_lmb()
            winmm.timeEndPeriod(1)

    def _loop(self):
        state = "wait1"
        plan = ClickPlanner()
        last_seen1 = 0.0
        ignore1_until = 0.0
        gone_since = None
        warned_focus = False
        roi = None
        roi_stage = 0
        roi_lost = None
        last_rect = None
        c_hist = []
        proc_ema = 0.008
        profile = 0
        cand_prof = None
        acc_prof = 0
        dbg_done = False
        seen2_cnt = 0
        seen2 = False
        spam_start = 0.0
        no_stage1_time = time.perf_counter()  # Страховка от долгого поиска 1-й шкалы

        self._set_state("wait1")
        self.log.emit(t("w_wait1"), "info")

        with mss.mss() as sct:
            while self._run:
                rect = client_rect(self.hwnd)
                if rect is None:
                    self.log.emit(t("w_closed"), "err")
                    break
                if user32.IsIconic(self.hwnd):
                    time.sleep(0.2)
                    continue
                if rect != last_rect:
                    last_rect = rect
                    roi = None
                    c_hist = []
                L, T, W, H = rect

                if (user32.GetForegroundWindow() or 0) != self.hwnd:
                    if not warned_focus:
                        self.log.emit(t("w_nofocus"), "warn")
                        warned_focus = True
                    plan.reset()
                    roi = None
                    self._set_state("paused")
                    time.sleep(0.05)
                    continue
                warned_focus = False

                want = 1 if state == "wait1" else (2 if seen2 else None)
                tracking = roi is not None and roi_stage == want
                if tracking:
                    ox, oy, rw, rh = roi
                    step = STEP
                else:
                    ox = oy = 0
                    rw, rh = W, H
                    step = STEP if rw * rh <= 1600000 else 3

                mon = sct.monitors[0]
                gl, gt = L + ox, T + oy
                cl, ct = max(gl, mon["left"]), max(gt, mon["top"])
                cr = min(gl + rw, mon["left"] + mon["width"])
                cb = min(gt + rh, mon["top"] + mon["height"])
                if cr - cl < 16 or cb - ct < 16:
                    time.sleep(0.2)
                    continue
                ox += cl - gl
                oy += ct - gt
                rw, rh = cr - cl, cb - ct
                region = {"left": L + ox, "top": T + oy, "width": rw, "height": rh}
                t0 = time.perf_counter()
                try:
                    shot = sct.grab(region)
                except Exception as e:
                    self.log.emit(t("w_capfail", e), "err")
                    time.sleep(0.5)
                    continue
                frame = np.frombuffer(shot.bgra, dtype=np.uint8).reshape(shot.height, shot.width, 4)
                
                # Если долго не видим шкалу целиком на экране, сбрасываем ROI и перебираем профили цветов (обход плохой видимости)
                if tracking and state == "wait1":
                    info = detect(frame, step, want, profile)
                    if not info["stage"]:
                        roi = None  # Сбрасываем старую зону поиска
                        tracking = False
                
                if tracking:
                    info = detect(frame, step, want, profile)
                else:
                    info, profile, cand_prof, acc_prof, new_prof = scan_all(
                        frame, step, want, profile, cand_prof, acc_prof)
                    if new_prof is not None:
                        self.log.emit(t("w_profile", new_prof), "info")
                
                now = time.perf_counter()
                proc_ema = 0.85 * proc_ema + 0.15 * (now - t0)
                if ox or oy:
                    _shift_info(info, ox, oy)

                if info["stage"] and (want is None or info["stage"] == want):
                    roi = _make_roi(info, W, H)
                    roi_stage = info["stage"]
                    roi_lost = None
                elif tracking:
                    if roi_lost is None:
                        roi_lost = now
                    elif now - roi_lost > 0.4:
                        roi = None
                        roi_lost = None
                        c_hist = []

                lead = float(CFG.get("lead_ms", LEAD * 1000.0)) / 1000.0 + proc_ema
                if state == "wait1" and info["stage"] == 1 and info["center"] is not None:
                    c_hist.append(info["center"])
                    del c_hist[:-25]
                    info["center"] = float(np.median(c_hist))

                if state == "wait1":
                    if info["stage"] == 1:
                        if now - last_seen1 > 1.0:
                            self.log.emit(t("w_seen1"), "info")
                        last_seen1 = now
                        no_stage1_time = now  # Сбрасываем таймер отсутствия шкалы
                    else:
                        # АВАРИЙНАЯ СТРАХОВКА: если шкалу 1 не видит больше 2.5 секунд после сброса, делаем пакет кликов/сброс ROI
                        if now - no_stage1_time > 2.5:
                            roi = None
                            plan.reset()
                            profile = (profile + 1) % len(PROFILES)  # Циклически меняем цветовой профиль для обхода плохой видимости
                            no_stage1_time = now

                    hook = self._pick_hook(info, plan.prev_x) if info["stage"] == 1 else None
                    if info["stage"] == 1 and hook is not None and now >= ignore1_until:
                        c = info["center"]
                        fire, pred = plan.update(now, hook, c, info["tol"], info["inner"],
                                                 info["colour_ok"], lead)
                        if fire:
                            if not self._safe_click(CLICK_HOLD_1):
                                continue
                            self.hit.emit()
                            self.log.emit(t("w_hit"), "ok")
                            self.log.emit(t("w_hitinfo", int(round(hook - c)), int(round(pred - c))), "info")
                            
                            # START AUTOCLICKER IMMEDIATELY AT 15 CPS
                            if CFG.get("click2_center", True):
                                try:
                                    user32.SetCursorPos(L + W // 2, T + H // 2)
                                except Exception:
                                    pass
                            self.clicker.start_clicking()
                            self.log.emit(t("w_clk_on"), "info")
                            state = "spam"
                            c_hist = []
                            plan.reset()
                            ignore1_until = now + 1.2
                            spam_start = now
                            seen2 = False
                            seen2_cnt = 0
                            gone_since = None
                            dbg_done = False
                            roi = None
                            self._set_state("click")
                            continue
                    else:
                        plan.reset()

                elif state == "spam":
                    off = None
                    if info["stage"] == 2:
                        gone_since = None
                        if not seen2:
                            seen2_cnt += 1
                            if seen2_cnt >= 1:
                                seen2 = True
                                self.log.emit(t("w_seen2"), "info")
                    elif not seen2:
                        seen2_cnt = 0
                    elif gone_since is None:
                        gone_since = now
                    
                    if seen2 and gone_since is not None and now - gone_since > SPAM_GONE_AFTER:
                        off = "gone"
                    elif not seen2 and info["stage"] == 1 and now >= ignore1_until:
                        off = "retry"
                    elif now - spam_start > (CLICK2_MAX if seen2 else WAIT2_TIMEOUT):
                        off = "timeout"
                    elif (not seen2 and not dbg_done and not tracking and info["stage"] == 0
                          and now - spam_start > 6.0):
                        dbg_done = True
                        self._save_debug(shot)
                    
                    if off:
                        self.clicker.stop_clicking()
                        self.log.emit(t("w_clk_off", self.clicker.count), "info")
                        if off == "gone":
                            self.cycle.emit()
                            self.log.emit(t("w_gone"), "info")
                        elif off == "retry":
                            self.log.emit(t("w_retry"), "warn")
                        else:
                            self.log.emit(t("w_timeout"), "warn")
                        state = "wait1"
                        plan.reset()
                        c_hist = []
                        roi = None  # Гарантированно сбрасываем ROI при возврате к 1 этапу после рыбы!
                        ignore1_until = 0.0 if off == "gone" else time.perf_counter() + 0.5
                        no_stage1_time = time.perf_counter()
                        self._set_state("wait1")

                time.sleep(SPAM_POLL if state == "spam" else (0.002 if tracking else 0.006))


# ----------------------------------------------------------------------------
#  small helpers for widgets
# ----------------------------------------------------------------------------
def lerp(c1, c2, t):
    a = QColor(c1)
    b = QColor(c2)
    t = max(0.0, min(1.0, t))
    return QColor(int(a.red() + (b.red() - a.red()) * t),
                  int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t),
                  int(a.alpha() + (b.alpha() - a.alpha()) * t))


def mk_label(text, size=10, bold=False, color=TEXT, spacing=0.0):
    lb = QLabel(text)
    f = QFont("Segoe UI", size)
    f.setBold(bold)
    if spacing:
        f.setLetterSpacing(QFont.AbsoluteSpacing, spacing)
    lb.setFont(f)
    lb.setStyleSheet("color:%s;background:transparent;" % color)
    return lb


def make_anim(obj, prop, ms, curve=QEasingCurve.OutCubic):
    a = QPropertyAnimation(obj, prop, obj)
    a.setDuration(ms)
    a.setEasingCurve(curve)
    return a


# ----------------------------------------------------------------------------
#  custom widgets
# ----------------------------------------------------------------------------
class GlowButton(QPushButton):
    def __init__(self, text, kind="primary", parent=None):
        super().__init__(text, parent)
        self.kind = kind
        self._hover = 0.0
        self._pulse = 0.0
        self._color = QColor(ACCENT)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.NoFocus)
        self._ha = make_anim(self, b"hover", 180)
        self._pa = make_anim(self, b"pulse", 1300, QEasingCurve.Linear)
        self._pa.setStartValue(0.0)
        self._pa.setEndValue(1.0)
        self._pa.setLoopCount(-1)
        self._ca = QVariantAnimation(self)
        self._ca.setDuration(260)
        self._ca.valueChanged.connect(self._on_color)

    def _g_hover(self):
        return self._hover

    def _s_hover(self, v):
        self._hover = v
        self.update()

    hover = Property(float, _g_hover, _s_hover)

    def _g_pulse(self):
        return self._pulse

    def _s_pulse(self, v):
        self._pulse = v
        self.update()

    pulse = Property(float, _g_pulse, _s_pulse)

    def _on_color(self, c):
        self._color = QColor(c)
        self.update()

    def set_color(self, c):
        if not anim_on():
            self._color = QColor(c)
            self.update()
            return
        self._ca.stop()
        self._ca.setStartValue(QColor(self._color))
        self._ca.setEndValue(QColor(c))
        self._ca.start()

    def set_pulsing(self, on):
        if on and anim_on():
            if self._pa.state() != QPropertyAnimation.Running:
                self._pa.start()
        else:
            self._pa.stop()
            self._pulse = 0.0
            self.update()

    def _hover_to(self, v):
        if anim_on():
            self._ha.stop()
            self._ha.setStartValue(self._hover)
            self._ha.setEndValue(v)
            self._ha.start()
        else:
            self._hover = v
            self.update()

    def enterEvent(self, e):
        self._hover_to(1.0)
        super().enterEvent(e)

    def leaveEvent(self, e):
        self._hover_to(0.0)
        super().leaveEvent(e)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(6, 6, -6, -6)
        rad = 12.0
        c = QColor(self._color)
        amp = 0.5 - 0.5 * math.cos(2 * math.pi * self._pulse) if self._pulse else 0.0
        if self.kind == "primary":
            glow = 26 * self._hover + 70 * amp
            p.setPen(Qt.NoPen)
            for i in range(1, 8):
                col = QColor(c)
                col.setAlpha(max(0, int(glow * (1 - i / 8.0) ** 2)))
                p.setBrush(col)
                p.drawRoundedRect(r.adjusted(-i, -i, i, i), rad + i, rad + i)
            g = QLinearGradient(r.topLeft(), r.bottomLeft())
            g.setColorAt(0, lerp(c, "#ffffff", 0.18 * self._hover))
            g.setColorAt(1, lerp(c, "#000000", 0.28))
            p.setBrush(g)
            p.drawRoundedRect(r, rad, rad)
            p.setPen(QColor("#0b0b0b") if c.lightness() > 135 else QColor("#ffffff"))
        else:
            p.setBrush(QColor(23, 23, 23, 230))
            p.setPen(QPen(lerp(BORDER, ACCENT, self._hover), 1.2))
            p.drawRoundedRect(r, rad, rad)
            p.setPen(lerp(TEXT, ACCENT, self._hover))
        f = QFont("Segoe UI", 13 if self.kind == "primary" else 12)
        f.setBold(True)
        if self.kind == "primary":
            f.setLetterSpacing(QFont.AbsoluteSpacing, 3)
        p.setFont(f)
        p.drawText(r, Qt.AlignCenter, self.text())


class Toggle(QWidget):
    toggled = Signal(bool)

    def __init__(self, checked=False, parent=None):
        super().__init__(parent)
        self.setFixedSize(52, 28)
        self.setCursor(Qt.PointingHandCursor)
        self._checked = checked
        self._k = 1.0 if checked else 0.0
        self._a = make_anim(self, b"knob", 200, QEasingCurve.OutBack)

    def _g(self):
        return self._k

    def _s(self, v):
        self._k = v
        self.update()

    knob = Property(float, _g, _s)

    def isChecked(self):
        return self._checked

    def set_checked(self, v, emit=False):
        v = bool(v)
        if v == self._checked:
            return
        self._checked = v
        self._anim_to(1.0 if v else 0.0)
        if emit:
            self.toggled.emit(v)

    def _anim_to(self, t):
        if anim_on():
            self._a.stop()
            self._a.setStartValue(self._k)
            self._a.setEndValue(t)
            self._a.start()
        else:
            self._k = t
            self.update()

    def mousePressEvent(self, e):
        e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.isEnabled() and self.rect().contains(e.position().toPoint()):
            self.set_checked(not self._checked, emit=True)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if not self.isEnabled():
            p.setOpacity(0.4)
        k = max(0.0, min(1.0, self._k))
        r = QRectF(self.rect()).adjusted(1, 3, -1, -3)
        p.setPen(QPen(lerp("#2f2f2f", ACCENT, k), 1))
        p.setBrush(lerp("#171717", "#2f2f2f", k))
        p.drawRoundedRect(r, r.height() / 2, r.height() / 2)
        d = r.height() - 6
        x = r.left() + 3 + (r.width() - d - 6) * self._k
        p.setPen(Qt.NoPen)
        if k > 0.05:
            gl = QColor(ACCENT)
            gl.setAlpha(int(60 * k))
            p.setBrush(gl)
            p.drawEllipse(QRectF(x - 3, r.top() + 0, d + 6, d + 6))
        p.setBrush(lerp("#717171", ACCENT, k))
        p.drawEllipse(QRectF(x, r.top() + 3, d, d))


class LangSwitch(QWidget):
    changed = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(76, 30)
        self.setCursor(Qt.PointingHandCursor)
        self._lang = CFG.get("lang", "ru")
        self._k = 1.0 if self._lang == "ru" else 0.0
        self._a = make_anim(self, b"slide", 220)

    def _g(self):
        return self._k

    def _s(self, v):
        self._k = v
        self.update()

    slide = Property(float, _g, _s)

    def set_lang(self, lang):
        self._lang = lang
        target = 1.0 if lang == "ru" else 0.0
        if anim_on():
            self._a.stop()
            self._a.setStartValue(self._k)
            self._a.setEndValue(target)
            self._a.start()
        else:
            self._k = target
            self.update()

    def mousePressEvent(self, e):
        e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            lang = "ru" if e.position().x() >= self.width() / 2.0 else "en"
            if lang != self._lang:
                self.set_lang(lang)
                self.changed.emit(lang)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = QRectF(self.rect()).adjusted(1, 2, -1, -2)
        rad = r.height() / 2.0
        p.setPen(QPen(QColor("#282828"), 1))
        p.setBrush(QColor("#0e0e0e"))
        p.drawRoundedRect(r, rad, rad)
        half = r.width() / 2.0
        k = max(0.0, min(1.0, self._k))
        seg = QRectF(r.left() + half * k, r.top(), half, r.height()).adjusted(2, 2, -2, -2)
        g = QLinearGradient(seg.topLeft(), seg.bottomLeft())
        g.setColorAt(0, lerp(ACCENT, "#ffffff", 0.12))
        g.setColorAt(1, lerp(ACCENT, "#000000", 0.30))
        p.setPen(Qt.NoPen)
        p.setBrush(g)
        p.drawRoundedRect(seg, seg.height() / 2.0, seg.height() / 2.0)
        f = QFont("Segoe UI", 8)
        f.setBold(True)
        f.setLetterSpacing(QFont.AbsoluteSpacing, 1)
        p.setFont(f)
        for i, txt in enumerate(("EN", "RU")):
            cell = QRectF(r.left() + half * i, r.top(), half, r.height())
            p.setPen(lerp(MUTED, "#0b0b0b", 1.0 - min(1.0, abs(k - i))))
            p.drawText(cell, Qt.AlignCenter, txt)


class Dot(QWidget):
    def __init__(self, size=12, color=MUTED, parent=None):
        super().__init__(parent)
        self.setFixedSize(size + 12, size + 12)
        self._d = size
        self._color = QColor(color)
        self._pulse = 0.0
        self._pa = make_anim(self, b"pulse", 1400, QEasingCurve.OutQuad)
        self._pa.setStartValue(0.0)
        self._pa.setEndValue(1.0)
        self._pa.setLoopCount(-1)
        self._ca = QVariantAnimation(self)
        self._ca.setDuration(250)
        self._ca.valueChanged.connect(self._on_color)

    def _g(self):
        return self._pulse

    def _s(self, v):
        self._pulse = v
        self.update()

    pulse = Property(float, _g, _s)

    def _on_color(self, c):
        self._color = QColor(c)
        self.update()

    def set_color(self, c):
        if anim_on():
            self._ca.stop()
            self._ca.setStartValue(QColor(self._color))
            self._ca.setEndValue(QColor(c))
            self._ca.start()
        else:
            self._color = QColor(c)
            self.update()

    def set_pulsing(self, on):
        if on and anim_on():
            if self._pa.state() != QPropertyAnimation.Running:
                self._pa.start()
        else:
            self._pa.stop()
            self._pulse = 0.0
            self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        c = QPointF(self.width() / 2.0, self.height() / 2.0)
        if self._pulse > 0:
            ring = QColor(self._color)
            ring.setAlpha(int(150 * (1 - self._pulse)))
            p.setPen(QPen(ring, 1.5))
            p.setBrush(Qt.NoBrush)
            rr = self._d / 2.0 + 6 * self._pulse
            p.drawEllipse(c, rr, rr)
        p.setPen(Qt.NoPen)
        p.setBrush(self._color)
        p.drawEllipse(c, self._d / 2.0, self._d / 2.0)


class TitleBtn(QWidget):
    clicked = Signal()

    def __init__(self, glyph, hover_color=ACCENT, spin=False, parent=None):
        super().__init__(parent)
        self.setFixedSize(34, 34)
        self.setCursor(Qt.PointingHandCursor)
        self.glyph = glyph
        self.hc = QColor(hover_color)
        self.spin = spin
        self._h = 0.0
        self._ang = 0.0
        self._ah = make_anim(self, b"hv", 200)
        self._aa = make_anim(self, b"ang", 520, QEasingCurve.OutBack)

    def _gh(self):
        return self._h

    def _sh(self, v):
        self._h = v
        self.update()

    hv = Property(float, _gh, _sh)

    def _ga(self):
        return self._ang

    def _sa(self, v):
        self._ang = v
        self.update()

    ang = Property(float, _ga, _sa)

    def enterEvent(self, e):
        if anim_on():
            self._ah.stop()
            self._ah.setStartValue(self._h)
            self._ah.setEndValue(1.0)
            self._ah.start()
            if self.spin:
                self._aa.stop()
                self._aa.setStartValue(self._ang)
                self._aa.setEndValue(self._ang + 120.0)
                self._aa.start()
        else:
            self._h = 1.0
            self.update()
        super().enterEvent(e)

    def leaveEvent(self, e):
        if anim_on():
            self._ah.stop()
            self._ah.setStartValue(self._h)
            self._ah.setEndValue(0.0)
            self._ah.start()
        else:
            self._h = 0.0
            self.update()
        super().leaveEvent(e)

    def mousePressEvent(self, e):
        e.accept()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        bg = QColor(self.hc)
        bg.setAlpha(int(34 * self._h))
        p.setPen(Qt.NoPen)
        p.setBrush(bg)
        p.drawEllipse(self.rect().adjusted(2, 2, -2, -2))
        p.translate(self.width() / 2.0, self.height() / 2.0)
        p.rotate(self._ang)
        p.setPen(lerp(MUTED, self.hc, self._h))
        p.setFont(QFont("Segoe UI Symbol", 13))
        p.drawText(QRectF(-17, -17, 34, 34), Qt.AlignCenter, self.glyph)


class ProcCombo(QComboBox):
    def __init__(self, refresh_cb, parent=None):
        super().__init__(parent)
        self._refresh_cb = refresh_cb
        self.setCursor(Qt.PointingHandCursor)
        self.setMaxVisibleItems(12)

    def showPopup(self):
        self._refresh_cb()
        super().showPopup()

    def paintEvent(self, e):
        super().paintEvent(e)
        p = QPainter(self)
        p.setPen(QColor(ACCENT if self.isEnabled() else MUTED))
        p.setFont(QFont("Segoe UI", 10))
        p.drawText(self.rect().adjusted(0, 0, -12, 0), Qt.AlignRight | Qt.AlignVCenter, "▾")


class StatCard(QFrame):
    def __init__(self, caption, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(0)
        self.value = mk_label("0", 17, True)
        self.value.setAlignment(Qt.AlignCenter)
        self._key = caption
        cap = mk_label(t(caption), 7, True, MUTED, 1.6)
        self.cap = cap
        cap.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.value)
        lay.addWidget(cap)
        self._fa = QVariantAnimation(self)
        self._fa.setDuration(550)
        self._fa.setStartValue(0.0)
        self._fa.setEndValue(1.0)
        self._fa.valueChanged.connect(
            lambda t: self.value.setStyleSheet("color:%s;background:transparent;" % lerp(MUTED, TEXT, t).name()))

    def set_value(self, text, flash=False):
        self.value.setText(str(text))
        if flash and anim_on():
            self._fa.stop()
            self._fa.start()

    def retr(self):
        self.cap.setText(t(self._key))


STATE_COL = {
    "idle": MUTED,
    "wait1": INFO,
    "wait2": WARN,
    "click": ACCENT,
    "paused": ORANGE,
}


def state_meta(st):
    st = st if st in STATE_COL else "idle"
    return t("st_" + st), STATE_COL[st]


class Dim(QWidget):
    clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._amt = 0.0
        self.hide()

    def _g(self):
        return self._amt

    def _s(self, v):
        self._amt = v
        self.update()

    amount = Property(float, _g, _s)

    def mousePressEvent(self, e):
        self.clicked.emit()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 18, 18)
        p.fillPath(path, QColor(0, 0, 0, int(165 * self._amt)))


class SettingsPanel(QFrame):
    close_requested = Signal()
    hotkey_changed = Signal(int)
    anim_changed = Signal(bool)
    console_changed = Signal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("panel")
        self.capturing = False
        self._base = set()
        self._tr = []
        self._ct = QTimer(self)
        self._ct.timeout.connect(self._poll)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.setSpacing(16)

        head = QHBoxLayout()
        self.l_title = mk_label(t("settings"), 12, True, TEXT, 2.5)
        self._tr.append((self.l_title, "settings"))
        head.addWidget(self.l_title)
        head.addStretch()
        close = TitleBtn("✕", DANGER)
        close.clicked.connect(self.close_requested.emit)
        head.addWidget(close)
        lay.addLayout(head)

        lay.addWidget(self._line())

        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        l1 = mk_label(t("set_key"), 10, True)
        l2 = mk_label(t("set_key_d"), 8, False, MUTED)
        self._tr += [(l1, "set_key"), (l2, "set_key_d")]
        col.addWidget(l1)
        col.addWidget(l2)
        row.addLayout(col)
        row.addStretch()
        self.keybtn = GlowButton(vk_name(CFG["hotkey"]), "ghost")
        self.keybtn.setFixedSize(124, 44)
        self.keybtn.clicked.connect(self.start_capture)
        row.addWidget(self.keybtn)
        lay.addLayout(row)

        self.t_anim = Toggle(CFG["animations"])
        self.t_anim.toggled.connect(self.anim_changed.emit)
        lay.addLayout(self._toggle_row("set_anim", "set_anim_d", self.t_anim))

        self.t_console = Toggle(CFG["console"])
        self.t_console.toggled.connect(self.console_changed.emit)
        lay.addLayout(self._toggle_row("set_console", "set_console_d", self.t_console))

        lay.addStretch()
        lay.addWidget(self._line())
        foot = QLabel(self._foot_text())
        self.foot = foot
        foot.setTextFormat(Qt.RichText)
        foot.setTextInteractionFlags(Qt.TextSelectableByMouse)
        foot.setAlignment(Qt.AlignCenter)
        f = QFont("Segoe UI", 9)
        f.setBold(True)
        foot.setFont(f)
        foot.setStyleSheet("color:%s;background:transparent;" % MUTED)
        lay.addWidget(foot)

    def _line(self):
        ln = QFrame()
        ln.setFixedHeight(1)
        ln.setStyleSheet("background:%s;" % BORDER)
        return ln

    def _toggle_row(self, tkey, dkey, toggle):
        row = QHBoxLayout()
        col = QVBoxLayout()
        col.setSpacing(2)
        l1 = mk_label(t(tkey), 10, True)
        l2 = mk_label(t(dkey), 8, False, MUTED)
        self._tr += [(l1, tkey), (l2, dkey)]
        col.addWidget(l1)
        col.addWidget(l2)
        row.addLayout(col)
        row.addStretch()
        row.addWidget(toggle)
        return row

    def _foot_text(self):
        return t("creator", "<span style='color:%s'>%s</span>" % (ACCENT, CREATOR))

    def retranslate(self):
        for lb, key in self._tr:
            lb.setText(t(key))
        self.foot.setText(self._foot_text())
        if not self.capturing:
            self.keybtn.setText(vk_name(CFG["hotkey"]))

    def start_capture(self):
        if self.capturing:
            return
        self.capturing = True
        self._base = {vk for vk in range(3, 255) if user32.GetAsyncKeyState(vk) & 0x8000}
        self.keybtn.setText(t("press_key"))
        self.keybtn.set_color(WARN)
        self._ct.start(20)

    def _poll(self):
        for vk in range(3, 255):
            down = bool(user32.GetAsyncKeyState(vk) & 0x8000)
            if not down:
                self._base.discard(vk)
                continue
            if vk in self._base:
                continue
            self._ct.stop()
            self.capturing = False
            if vk != 0x1B:
                CFG["hotkey"] = vk
                save_cfg()
                self.hotkey_changed.emit(vk)
            self.keybtn.setText(vk_name(CFG["hotkey"]))
            return


# ----------------------------------------------------------------------------
#  main window
# ----------------------------------------------------------------------------
QSS = """
QWidget { color: #eaeaea; }
QFrame#card { background: rgba(18,18,18,205); border: 1px solid #222222; border-radius: 14px; }
QFrame#note { background: rgba(255,255,255,10); border: 1px solid rgba(255,255,255,40);
              border-left: 3px solid #cdcdcd; border-radius: 10px; }
QFrame#panel { background: #0f0f0f; border: 1px solid #282828; border-radius: 16px; }
QComboBox { background: #0e0e0e; border: 1px solid #282828; border-radius: 10px;
            padding: 9px 30px 9px 12px; color: #eaeaea; }
QComboBox:hover { border-color: #f2f2f2; }
QComboBox:disabled { color: #626262; }
QComboBox::drop-down { border: none; width: 0px; }
QComboBox::down-arrow { image: none; width: 0px; }
QComboBox QAbstractItemView { background: #0e0e0e; border: 1px solid #282828; outline: 0;
            selection-background-color: rgba(255,255,255,38); selection-color: #f2f2f2; padding: 4px; }
QPlainTextEdit { background: transparent; border: none; color: #a1a1a1;
                 selection-background-color: rgba(255,255,255,80); }
QScrollBar:vertical { background: transparent; width: 8px; margin: 2px; }
QScrollBar::handle:vertical { background: #2f2f2f; border-radius: 4px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: #f2f2f2; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
"""

TITLE_H = 44


class MainWindow(QWidget):
    W, H = 1020, 680

    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.Window)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedSize(self.W, self.H)
        self.setWindowTitle(APP_NAME)
        self.setStyleSheet(QSS)

        self.worker = None
        self.mode = None
        self.t0 = 0.0
        self.hits = 0
        self.cycles = 0
        self._hk_last = False
        self._settings_open = False
        self._cur_state = "idle"

        rnd = random.Random(7)
        self._orbs = []
        for col in ((255, 255, 255), (220, 220, 225), (150, 150, 158)):
            self._orbs.append({"x": rnd.uniform(100, self.W - 100), "y": rnd.uniform(100, self.H - 100),
                               "vx": rnd.uniform(-0.6, 0.6) or 0.3, "vy": rnd.uniform(-0.5, 0.5) or 0.2,
                               "r": rnd.uniform(220, 300), "c": col})
        self._make_sprites()
        self._bg = QTimer(self)
        self._bg.timeout.connect(self._bg_tick)

        self._build()
        self._build_overlay()
        self.refresh_processes()
        self.apply_console()
        self.apply_anim()

        self._hk = QTimer(self)
        self._hk.timeout.connect(self._poll_hotkey)
        self._hk.start(25)

        self._st = QTimer(self)
        self._st.timeout.connect(self._tick_stats)
        self._st.start(500)

        self.log(t("log_ready"), "ok")
        self.log(t("log_hint", vk_name(CFG["hotkey"])), "info")

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 12, 24, 22)
        root.setSpacing(10)

        tb = QHBoxLayout()
        tb.setSpacing(8)
        tb.addWidget(Dot(12, ACCENT))
        t1 = mk_label("AUTO FISH", 13, True, TEXT, 3)
        t2 = mk_label("by barabaka", 10, False, ACCENT)
        tb.addWidget(t1)
        tb.addWidget(t2)
        tb.addStretch()
        self.lang_sw = LangSwitch()
        self.lang_sw.changed.connect(self.on_lang)
        self.gear = TitleBtn("⚙", ACCENT, spin=True)
        self.gear.clicked.connect(self.open_settings)
        mini = TitleBtn("—", INFO)
        mini.clicked.connect(self.showMinimized)
        close = TitleBtn("✕", DANGER)
        close.clicked.connect(self.close)
        tb.addWidget(self.lang_sw)
        tb.addWidget(self.gear)
        tb.addWidget(mini)
        tb.addWidget(close)
        tbw = QWidget()
        tbw.setFixedHeight(TITLE_H - 6)
        tbw.setLayout(tb)
        tb.setContentsMargins(0, 0, 0, 0)
        root.addWidget(tbw)
        root.addSpacing(8)

        body = QHBoxLayout()
        body.setSpacing(16)
        root.addLayout(body, 1)

        left = QVBoxLayout()
        left.setSpacing(12)
        lw = QWidget()
        lw.setFixedWidth(330)
        lw.setLayout(left)
        left.setContentsMargins(0, 0, 0, 0)
        body.addWidget(lw)

        card = QFrame()
        card.setObjectName("card")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(16, 14, 16, 16)
        cl.setSpacing(10)
        self.l_proc = mk_label(t("proc_title"), 8, True, MUTED, 1.8)
        cl.addWidget(self.l_proc)
        row = QHBoxLayout()
        row.setSpacing(4)
        self.combo = ProcCombo(self.refresh_processes)
        self.combo.setFont(QFont("Segoe UI", 10))
        row.addWidget(self.combo, 1)
        self.refresh_btn = GlowButton("⟳", "ghost")
        self.refresh_btn.setFixedSize(52, 46)
        self.refresh_btn.clicked.connect(self.refresh_processes)
        row.addWidget(self.refresh_btn)
        cl.addLayout(row)
        left.addWidget(card)

        note = QFrame()
        note.setObjectName("note")
        self.note = note
        nl = QVBoxLayout(note)
        nl.setContentsMargins(14, 12, 14, 8)
        nl.setSpacing(4)
        self.l_note_t = mk_label(t("note_title"), 8, True, WARN, 1.8)
        nl.addWidget(self.l_note_t)
        self.l_note = mk_label(t("note_text"), 10, False, TEXT)
        self.l_note.setWordWrap(True)
        nl.addWidget(self.l_note)
        nrow = QHBoxLayout()
        nrow.addStretch()
        self.ok_btn = GlowButton(t("ok"), "ghost")
        self.ok_btn.setFixedSize(76, 40)
        self.ok_btn.clicked.connect(self.hide_note)
        nrow.addWidget(self.ok_btn)
        nl.addLayout(nrow)
        left.addWidget(note)

        self.start_btn = GlowButton(t("start"), "primary")
        self.start_btn.setFixedHeight(72)
        self.start_btn.clicked.connect(self.toggle)
        left.addWidget(self.start_btn)

        sc = QFrame()
        sc.setObjectName("card")
        sl = QHBoxLayout(sc)
        sl.setContentsMargins(10, 8, 16, 8)
        self.dot = Dot(10, MUTED)
        sl.addWidget(self.dot)
        self.state_lbl = mk_label(t("st_idle"), 9, True, MUTED, 1.5)
        sl.addWidget(self.state_lbl)
        sl.addStretch()
        self.hk_lbl = mk_label("", 8, True, MUTED, 1.0)
        sl.addWidget(self.hk_lbl)
        left.addWidget(sc)

        stats = QHBoxLayout()
        stats.setSpacing(10)
        self.s_hits = StatCard("hits")
        self.s_cycles = StatCard("cycles")
        self.s_time = StatCard("uptime")
        self.s_time.set_value("00:00")
        for s in (self.s_hits, self.s_cycles, self.s_time):
            stats.addWidget(s)
        left.addLayout(stats)
        left.addStretch()
        self.update_hk_label()

        right = QVBoxLayout()
        right.setSpacing(12)
        body.addLayout(right, 1)
        self.console_card = QFrame()
        self.console_card.setObjectName("card")
        cc = QVBoxLayout(self.console_card)
        cc.setContentsMargins(16, 12, 12, 12)
        cc.setSpacing(6)
        self.l_console = mk_label(t("console"), 8, True, MUTED, 1.8)
        cc.addWidget(self.l_console)
        self.console = QPlainTextEdit()
        self.console.setReadOnly(True)
        self.console.setMaximumBlockCount(600)
        self.console.setFont(QFont("Consolas", 10))
        cc.addWidget(self.console, 1)
        right.addWidget(self.console_card, 3)

    def _build_overlay(self):
        self.dim = Dim(self)
        self.dim.setGeometry(self.rect())
        self.dim.clicked.connect(self.close_settings)
        self.panel = SettingsPanel(self)
        self.panel.setFixedSize(340, self.H - 28)
        self.panel.close_requested.connect(self.close_settings)
        self.panel.hotkey_changed.connect(lambda _: self.update_hk_label())
        self.panel.anim_changed.connect(self.on_anim_toggle)
        self.panel.console_changed.connect(self.on_console_toggle)
        self._open_rect = QRect(self.W - 340 - 14, 14, 340, self.H - 28)
        self._closed_rect = QRect(self.W + 10, 14, 340, self.H - 28)
        self.panel.setGeometry(self._closed_rect)
        self.panel.show()
        self.a_panel = QPropertyAnimation(self.panel, b"geometry", self)
        self.a_panel.setDuration(260)
        self.a_panel.finished.connect(self._after_settings_anim)
        self.a_dim = QPropertyAnimation(self.dim, b"amount", self)
        self.a_dim.setDuration(220)

    def _make_sprites(self):
        self._sprites = []
        for o in self._orbs:
            r = int(o["r"])
            pm = QPixmap(r * 2, r * 2)
            pm.fill(Qt.transparent)
            q = QPainter(pm)
            q.setRenderHint(QPainter.Antialiasing)
            g = QRadialGradient(QPointF(r, r), r)
            g.setColorAt(0, QColor(o["c"][0], o["c"][1], o["c"][2], 16))
            g.setColorAt(1, QColor(o["c"][0], o["c"][1], o["c"][2], 0))
            q.setPen(Qt.NoPen)
            q.setBrush(g)
            q.drawEllipse(QPointF(r, r), r, r)
            q.end()
            self._sprites.append(pm)
        full = QPainterPath()
        full.addRect(QRectF(0, 0, self.W, self.H))
        rr = QPainterPath()
        rr.addRoundedRect(QRectF(0, 0, self.W, self.H).adjusted(0.5, 0.5, -0.5, -0.5), 18, 18)
        self._corners = full.subtracted(rr)

    def _freeze(self, on):
        if on:
            self._bg.stop()
        elif anim_on():
            self._bg.start(33)

    def _bg_tick(self):
        for o in self._orbs:
            o["x"] += o["vx"]
            o["y"] += o["vy"]
            if o["x"] < 0 or o["x"] > self.W:
                o["vx"] = -o["vx"]
            if o["y"] < 0 or o["y"] > self.H:
                o["vy"] = -o["vy"]
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5), 18, 18)
        p.fillPath(path, QColor("#090909"))
        for o, sp in zip(self._orbs, self._sprites):
            r = sp.width() / 2.0
            p.drawPixmap(int(o["x"] - r), int(o["y"] - r), sp)
        p.save()
        p.setCompositionMode(QPainter.CompositionMode_Clear)
        p.fillPath(self._corners, QColor(0, 0, 0, 255))
        p.restore()
        y = TITLE_H + 14
        if anim_on():
            t = (time.time() * 0.22) % 1.0
            g = QLinearGradient(0, 0, self.W, 0)
            base = QColor(34, 34, 34)
            g.setColorAt(0, base)
            g.setColorAt(1, base)
            for off, a in ((-0.12, 0), (0.0, 200), (0.12, 0)):
                pos = t + off
                if 0.0 <= pos <= 1.0:
                    g.setColorAt(pos, QColor(255, 255, 255, a) if a else base)
            p.setPen(QPen(QBrush(g), 1.5))
        else:
            p.setPen(QPen(QColor(34, 34, 34), 1.5))
        p.drawLine(24, y, self.W - 24, y)
        p.setClipping(False)
        p.setPen(QPen(QColor("#232323"), 1))
        p.setBrush(Qt.NoBrush)
        p.drawPath(path)

    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton or e.position().y() >= TITLE_H + 10 or not self.windowHandle():
            return
        if self._settings_open:
            return
        w = self.childAt(e.position().toPoint())
        if isinstance(w, (TitleBtn, GlowButton, Toggle, LangSwitch, QComboBox)):
            return
        self.windowHandle().startSystemMove()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape and self._settings_open and not self.panel.capturing:
            self.close_settings()
        else:
            super().keyPressEvent(e)

    def showEvent(self, e):
        super().showEvent(e)
        if anim_on() and not getattr(self, "_faded", False):
            self._faded = True
            self.setWindowOpacity(0.0)
            a = QPropertyAnimation(self, b"windowOpacity", self)
            a.setDuration(450)
            a.setStartValue(0.0)
            a.setEndValue(1.0)
            a.setEasingCurve(QEasingCurve.OutCubic)
            a.start()
            self._fade = a

    def closeEvent(self, e):
        self.stop_worker(quiet=True)
        super().closeEvent(e)

    def open_settings(self):
        if self._settings_open:
            return
        self._settings_open = True
        self.dim.setGeometry(self.rect())
        self.dim.show()
        self.dim.raise_()
        self.panel.show()
        self.panel.raise_()
        if anim_on():
            self.a_panel.stop()
            self.a_panel.setEasingCurve(QEasingCurve.OutCubic)
            self._freeze(True)
            self.a_panel.setStartValue(self._closed_rect)
            self.a_panel.setEndValue(self._open_rect)
            self.a_panel.start()
            self.a_dim.stop()
            self.a_dim.setStartValue(self.dim.amount)
            self.a_dim.setEndValue(1.0)
            self.a_dim.start()
        else:
            self.panel.setGeometry(self._open_rect)
            self.dim.amount = 1.0

    def close_settings(self):
        if not self._settings_open or self.panel.capturing:
            return
        self._settings_open = False
        if anim_on():
            self.a_panel.stop()
            self.a_panel.setEasingCurve(QEasingCurve.InCubic)
            self._freeze(True)
            self.a_panel.setStartValue(self.panel.geometry())
            self.a_panel.setEndValue(self._closed_rect)
            self.a_panel.start()
            self.a_dim.stop()
            self.a_dim.setStartValue(self.dim.amount)
            self.a_dim.setEndValue(0.0)
            self.a_dim.start()
        else:
            self.dim.amount = 0.0
            self.panel.setGeometry(self._closed_rect)
            self.dim.hide()

    def _after_settings_anim(self):
        if not self._settings_open:
            self.dim.hide()
        self._freeze(False)

    def on_anim_toggle(self, v):
        CFG["animations"] = bool(v)
        save_cfg()
        self.apply_anim()

    def on_console_toggle(self, v):
        CFG["console"] = bool(v)
        save_cfg()
        self.apply_console()

    def apply_anim(self):
        on = anim_on()
        if on:
            self._bg.start(33)
        else:
            self._bg.stop()
        self.start_btn.set_pulsing(self.mode == "run")
        self.dot.set_pulsing(self.mode is not None)
        self.update()

    def apply_console(self):
        self.console_card.setVisible(bool(CFG["console"]))

    def update_hk_label(self):
        self.hk_lbl.setText(t("hk", vk_name(CFG["hotkey"]).upper()))

    def hide_note(self):
        n = self.note
        if not n.isVisible():
            return
        self.ok_btn.setEnabled(False)
        if not anim_on():
            n.hide()
            return
        eff = QGraphicsOpacityEffect(n)
        n.setGraphicsEffect(eff)
        a = QPropertyAnimation(eff, b"opacity", self)
        a.setDuration(260)
        a.setStartValue(1.0)
        a.setEndValue(0.0)
        a.finished.connect(n.hide)
        a.start()
        self._note_a = a

    def on_lang(self, lang):
        CFG["lang"] = lang
        save_cfg()
        self.retranslate()

    def retranslate(self):
        self.l_proc.setText(t("proc_title"))
        self.l_note_t.setText(t("note_title"))
        self.l_note.setText(t("note_text"))
        self.ok_btn.setText(t("ok"))
        self.start_btn.setText(t("stop") if self.mode == "run" else t("start"))
        for sc in (self.s_hits, self.s_cycles, self.s_time):
            sc.retr()
        self.l_console.setText(t("console"))
        self.update_hk_label()
        self.on_state(self._cur_state)
        self.panel.retranslate()

    def refresh_processes(self):
        prev = self.combo.currentData()
        wins = list_windows()

        def rank(w):
            n = (w["name"] + " " + w["title"]).lower()
            return 0 if ("gta5" in n or "ragemp" in n or "rage" in n or "grand theft" in n) else 1

        wins.sort(key=lambda w: (rank(w), w["name"].lower(), w["title"].lower()))
        self.combo.blockSignals(True)
        self.combo.clear()
        for w in wins:
            star = "★ " if rank(w) == 0 else ""
            title = w["title"] if len(w["title"]) <= 30 else w["title"][:29] + "…"
            self.combo.addItem("%s%s  ·  %s" % (star, w["name"], title), w["hwnd"])
        idx = self.combo.findData(prev) if prev is not None else -1
        self.combo.setCurrentIndex(idx if idx >= 0 else (0 if wins else -1))
        self.combo.blockSignals(False)

    def _selected(self):
        hwnd = self.combo.currentData()
        if hwnd is None or not user32.IsWindow(int(hwnd)):
            return None, ""
        return int(hwnd), self.combo.currentText().replace("★ ", "").split("  ·  ")[0]

    def log(self, text, kind="info"):
        colors = {"info": "#a1a1a1", "ok": ACCENT, "wait": WARN, "warn": ORANGE, "err": DANGER}
        ts = time.strftime("%H:%M:%S")
        self.console.appendHtml(
            "<span style='color:#505050'>[%s]</span> <span style='color:%s'>%s</span>"
            % (ts, colors.get(kind, "#a1a1a1"), html.escape(text)))

    def toggle(self):
        if self.worker is not None:
            self.stop_worker()
        else:
            self.start_worker()

    def start_worker(self):
        hwnd, name = self._selected()
        if hwnd is None:
            self.log(t("log_selproc"), "warn")
            return False
        self.stop_worker(quiet=True)
        w = Worker(hwnd)
        w.log.connect(self.log)
        w.state.connect(self.on_state)
        w.hit.connect(self.on_hit)
        w.cycle.connect(self.on_cycle)
        w.finished.connect(lambda w=w: self.on_finished(w))
        self.worker = w
        self.hits = 0
        self.cycles = 0
        self.s_hits.set_value(0)
        self.s_cycles.set_value(0)
        self.s_time.set_value("00:00")
        self.t0 = time.time()
        self.set_mode("run")
        w.start()
        self.log(t("log_started", name), "ok")
        if not is_admin():
            self.log(t("log_noadmin"), "warn")
        focus_window(hwnd)
        return True

    def stop_worker(self, quiet=False):
        w = self.worker
        if w is None:
            return
        self.worker = None
        w.stop()
        w.wait(2500)
        self.set_mode(None)
        self.on_state("idle")
        if not quiet:
            self.log(t("log_stopped"), "warn")

    def on_finished(self, w):
        if w is not self.worker:
            return
        self.worker = None
        self.set_mode(None)
        self.on_state("idle")
        self.log(t("log_stopped"), "warn")

    def set_mode(self, mode):
        self.mode = mode
        run = mode == "run"
        self.start_btn.setText(t("stop") if run else t("start"))
        self.start_btn.set_color(STOP_COL if run else ACCENT)
        self.start_btn.set_pulsing(run)
        self.combo.setEnabled(not run)
        self.refresh_btn.setEnabled(not run)
        self.dot.set_pulsing(mode is not None)

    def on_state(self, s):
        self._cur_state = s
        label, col = state_meta(s)
        self.state_lbl.setText(label)
        self.state_lbl.setStyleSheet("color:%s;background:transparent;" % col)
        self.dot.set_color(col)

    def on_hit(self):
        self.hits += 1
        self.s_hits.set_value(self.hits, flash=True)

    def on_cycle(self):
        self.cycles += 1
        self.s_cycles.set_value(self.cycles, flash=True)

    def _tick_stats(self):
        if self.mode == "run":
            s = int(time.time() - self.t0)
            self.s_time.set_value("%02d:%02d" % (s // 60, s % 60) if s < 3600
                                  else "%d:%02d:%02d" % (s // 3600, s % 3600 // 60, s % 60))

    def _poll_hotkey(self):
        cur = bool(user32.GetAsyncKeyState(CFG["hotkey"]) & 0x8000)
        if cur and not self._hk_last and not self.panel.capturing:
            self.toggle()
        self._hk_last = cur


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin():
    try:
        if getattr(sys, "frozen", False):
            exe, args = sys.executable, sys.argv[1:]
        else:
            exe, args = sys.executable, [os.path.abspath(sys.argv[0])] + sys.argv[1:]
        params = " ".join('"%s"' % a_ for a_ in args)
        workdir = os.path.dirname(os.path.abspath(sys.argv[0]))
        ctypes.windll.shell32.ShellExecuteW.restype = ctypes.c_void_p
        res = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, workdir, 1)
        return (res or 0) > 32
    except Exception:
        return False


def main():
    if not is_admin() and relaunch_as_admin():
        return
    try:
        ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except Exception:
        pass
    load_cfg()
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    w = MainWindow()
    scr = app.primaryScreen().availableGeometry()
    w.move(scr.center().x() - w.width() // 2, scr.center().y() - w.height() // 2)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
