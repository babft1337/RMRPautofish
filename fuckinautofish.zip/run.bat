@echo off
chcp 65001 > nul
title Auto Fish by Barabaka Launcher

echo ===================================================
echo   Auto Fish by Barabaka - Запуск и Установка
echo ===================================================
echo.

:: 1. Проверка наличия requirements.txt
if not exist "requirements.txt" (
    echo [INFO] Создание файла requirements.txt...
    echo numpy > requirements.txt
    echo mss >> requirements.txt
    echo PySide6 >> requirements.txt
    echo requests >> requirements.txt
)

:: 2. Автоматическая установка библиотек через python или py
echo [INFO] Проверка и установка библиотек...
python -m pip install -r requirements.txt >nul 2>&1
if %errorlevel% neq 0 (
    py -m pip install -r requirements.txt >nul 2>&1
)

echo.
echo ===================================================
echo [УСПЕХ] Запуск скрипта...
echo ===================================================
echo.

:: 3. Запуск основного файла
python "auto_fish_by_barabaka(8).py"
if %errorlevel% neq 0 (
    py "auto_fish_by_barabaka(8).py"
)

pause